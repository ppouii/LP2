﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        Double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
                       
                        if (imc < 18.5)
                        {
                            mskbxImc.Text = imc.ToString();
                            txtClassificacao.Text = "Magreza";
                        }
                        else
                        {
                            if (imc < 25)
                            {
                                mskbxImc.Text = imc.ToString();
                                txtClassificacao.Text = "Normal";
                            }
                            else
                            {
                                if (imc < 30)
                                {
                                    mskbxImc.Text = imc.ToString();
                                    txtClassificacao.Text = "Sobrepeso";
                                }
                            
                                else
                                {
                                    if(imc< 40)
                                    {
                                        mskbxImc.Text = imc.ToString();
                                        txtClassificacao.Text = "Obesidade";
                                    }
                                    else 
                                    {
                                        mskbxImc.Text = imc.ToString();
                                        txtClassificacao.Text = "Obesidade grave";
                                    }
                                }
                            

                            }

                        }
                

                

                


            
          
            
               

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Caracter inválido");
                mskbxPeso.Focus();
            }
            if (peso >= 300 || peso ==0) 
            {
                MessageBox.Show("Digite um peso menor que 300 KG e maior que zero");
                mskbxPeso.Focus();
            }
            
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Caracter inválido");
                mskbxAltura.Focus();
            }
            if (altura >= 2.30 || altura==0)
            {
                MessageBox.Show("Digite uma altura menor que 2.30 e maior que zero");
                mskbxAltura.Focus();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxImc.Clear();
            mskbxPeso.Clear();
            txtClassificacao.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();

            }
            else
            {

            }

        }
    }
}
