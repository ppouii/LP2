﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        Double primeiro=0, segundo=0, terceiro=0, result;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtSegundoValor_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtSegundoValor, "");
            if (!Double.TryParse(txtSegundoValor.Text, out segundo))
            {
                errorProvider2.SetError(txtPrimeiroValor, "O segundo valor é inválido"); 
               
            }
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if(primeiro<(segundo+terceiro)&& primeiro>Math.Abs(segundo - terceiro)&& segundo<
                (primeiro+terceiro)&& segundo > Math.Abs(primeiro-terceiro) && terceiro < (primeiro+segundo)
                && terceiro>Math.Abs(primeiro -segundo))
            {
                if (primeiro == segundo && segundo == terceiro)
                    MessageBox.Show($"Os valores {primeiro}, {segundo} e {terceiro} formam um triângulo equilátero");
                else
                {
                    if(primeiro==segundo || primeiro==terceiro || terceiro==segundo)
                        MessageBox.Show($"Os valores {primeiro}, {segundo} e {terceiro} formam um triângulo isósceles");
                    else
                        MessageBox.Show($"Os valores {primeiro}, {segundo} e {terceiro} formam um triângulo escaleno");

                }
                
            }
            else
                MessageBox.Show($"Os valores {primeiro}, {segundo} e {terceiro} não formam um triângulo");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtPrimeiroValor.Clear();
            txtSegundoValor.Clear();
            txtTerceiroValor.Clear();
            txtPrimeiroValor.Focus();
        }

        private void TxtTerceiroValor_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtPrimeiroValor, "");
            if (!Double.TryParse(txtTerceiroValor.Text, out terceiro))
            {
                errorProvider1.SetError(txtPrimeiroValor, "O Terceiro valor inválido");

            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();

            }
            else
            {

            }
        }

        private void TxtPrimeiroValor_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtPrimeiroValor, "");
            if(!Double.TryParse(txtPrimeiroValor.Text,out primeiro) )
            {
                errorProvider1.SetError(txtPrimeiroValor, "O primeiro valor é inválido");
            }
        }
    }
}
