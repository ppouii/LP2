﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalarioLiquido
{
    public partial class Form1 : Form
    {
        Double salarioBruto, salarioLiquido;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();

            }
            else
            {

            }

        }

        private void TxtNomeFuncionario_Validated(object sender, EventArgs e)
        {

            if (txtNomeFuncionario.Text == "")
            {
                MessageBox.Show("Digite o nome do funcionário");
                txtNomeFuncionario.Focus();
            }
            else { }
;
        }
        private void BtnVerificaDesconto_Click(object sender, EventArgs e)
        {
            Double descontoINSS, descontoIRPF, salarioFamilia;
            int numFilhos;

             numFilhos=Convert.ToInt32(Math.Round(nupFilhos.Value,0));
      
            if (salarioBruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7.65%";
                descontoINSS = 0.0765 * salarioBruto;
               
            }
            else if (salarioBruto <=1050)
            {
                txtAliquotaINSS.Text = "8.65%";
                descontoINSS = 0.0865 * salarioBruto;
            }
                else if (salarioBruto<=1400.77)
                {
                txtAliquotaINSS.Text = "9.00%";
                descontoINSS = 0.0900 * salarioBruto;
            }
                else if(salarioBruto<=2801.56)
            {
                txtAliquotaINSS.Text = "11.00%";
                descontoINSS = 0.1100 * salarioBruto;
            }
                else 
                {
                    txtAliquotaINSS.Text = "Teto";
                    descontoINSS = 308.17;
                }

            if(salarioBruto<=1257.12)
            {
                txtAliquotaIRPF.Text = "Isento";
                descontoIRPF = 0;
            }
            else if(salarioBruto<=2512.08)
            {
                txtAliquotaIRPF.Text = "15.00%";
                descontoIRPF = 0.1500 * salarioBruto;
            }
                else
                {
                    txtAliquotaIRPF.Text = "27.50%";
                    descontoIRPF = 0.2750 * salarioBruto;
                }


            if (salarioBruto<=435.52)
            {
     
                salarioFamilia = 22.33 * numFilhos;
            }
                else if (salarioBruto <= 654.61)
                {
                 
                    salarioFamilia = 15.74 * numFilhos;
                }
                else
                {
                
                salarioFamilia = 0;
                }

            txtDescontoINSS.Text = descontoINSS.ToString();
            txtDescontoIRPF.Text = descontoIRPF.ToString();
            txtSalarioFamilia.Text = salarioFamilia.ToString();
            salarioLiquido = salarioBruto - descontoIRPF - descontoIRPF + salarioFamilia;
            txtSalarioLiquido.Text = salarioLiquido.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtDescontoINSS.Clear();
            txtDescontoIRPF.Clear();
            txtNomeFuncionario.Clear();
            txtSalarioFamilia.Clear();
            txtSalarioLiquido.Clear();
            mskbxSalarioBruto.Clear();
            txtAliquotaINSS.Clear();
            txtAliquotaIRPF.Clear();
            txtNomeFuncionario.Focus();
        }

        private void mskbxSalarioBruto_Validated(object sender, EventArgs e)
        {
           
            if (!Double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
            {
                MessageBox.Show("Digite o salário");
                mskbxSalarioBruto.Focus();
            }
            else { }
        }
    }
}
