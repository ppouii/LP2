﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";
            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com o número {i + 1}",
                    "Entrada de Dados");
                if (auxiliar == "")
                    return;
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida; // outro meio para inverter a string 
                }
            }
            //usando reverse
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(saida);
        }

        private void BtnExercicio2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            string mediaAlunos = "";
            double media;


            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {

                    auxiliar = Interaction.InputBox($"Entre com as notas do aluno {i + 1}\nNota {j + 1}",
                    "Entrada das notas");
                    if (auxiliar == "")
                        return;
                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Número inválido!");
                        j--;
                    }
                    else if ((notas[i, j] > 10) || notas[i, j] < 0)
                    {
                        MessageBox.Show("Digite um número maior ou igual a zero e menor que 11");
                        j--;
                    }

                }
            }
            for (var k = 0; k < 20; k++)
            {
                media = (notas[k, 0] + notas[k, 1] + notas[k, 2]) / 3;
                mediaAlunos += $"Aluno {k + 1}: Média: " + media.ToString("n2") + "\n";
            }

            MessageBox.Show(mediaAlunos);

        }

        private void BtnExercicio3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
                                "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void BtnExercicio4_Click(object sender, EventArgs e)
        {
            System.Collections.ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Debóra");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            foreach (string i in alunos)
                MessageBox.Show(i);
                
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].Activate();
            }
            else
            {
                frmExercicio5 obj = new frmExercicio5();
                obj.Show();
            }
        }
    }
}




