﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] nomes = new string[8];
            int[] quantidadesCaracteres = new int[8];
           

            for (var i=0;i<8;i++)
            {
                auxiliar = Interaction.InputBox($"Entre com os nomes",
                    "Entrada dos nomes");
                nomes[i] = auxiliar;
                quantidadesCaracteres[i] = nomes[i].Replace(" ", "").Length;
            }
            for (var i = 0; i < 8; i++)
            {
                listBox1.Items.Add($"O nome: {nomes[i]}, tem " + quantidadesCaracteres[i].ToString() + "\n");
            }

          

        }
    }
}
