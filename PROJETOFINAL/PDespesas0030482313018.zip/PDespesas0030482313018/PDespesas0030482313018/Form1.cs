﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PDespesas0030482313018
{
    public partial class frmPrincipal : Form
    {
        private const string ConnectionString = "Data Source=DESKTOP-3IJ9053;Initial Catalog=LP2;Integrated Security=True;Pooling=False;Encrypt=True;TrustServerCertificate=True";
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
            
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmSobre"].Activate();
            }
            else
            {
                frmSobre obj2 = new frmSobre();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmDespesas>().Count() > 0)
            {
            
                Application.OpenForms["frmCadastrodeDespesas"].BringToFront();
            }
            else
            {
                frmDespesas objDesp = new frmDespesas();
                objDesp.MdiParent = this;
                objDesp.WindowState = FormWindowState.Maximized;
                objDesp.Show();
            }
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular

                conexao = new SqlConnection(ConnectionString);
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message, "Erro");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message, "Erro");
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
