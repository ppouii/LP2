﻿
namespace PDespesas0030482313018
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.lblNome6 = new System.Windows.Forms.Label();
            this.lblNome5 = new System.Windows.Forms.Label();
            this.lblNome4 = new System.Windows.Forms.Label();
            this.lblNome2 = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblObjetivo = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome6
            // 
            this.lblNome6.AutoSize = true;
            this.lblNome6.Location = new System.Drawing.Point(55, 264);
            this.lblNome6.Name = "lblNome6";
            this.lblNome6.Size = new System.Drawing.Size(0, 13);
            this.lblNome6.TabIndex = 13;
            // 
            // lblNome5
            // 
            this.lblNome5.AutoSize = true;
            this.lblNome5.Location = new System.Drawing.Point(55, 234);
            this.lblNome5.Name = "lblNome5";
            this.lblNome5.Size = new System.Drawing.Size(0, 13);
            this.lblNome5.TabIndex = 12;
            // 
            // lblNome4
            // 
            this.lblNome4.AutoSize = true;
            this.lblNome4.Location = new System.Drawing.Point(55, 206);
            this.lblNome4.Name = "lblNome4";
            this.lblNome4.Size = new System.Drawing.Size(0, 13);
            this.lblNome4.TabIndex = 11;
            // 
            // lblNome2
            // 
            this.lblNome2.AutoSize = true;
            this.lblNome2.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome2.Location = new System.Drawing.Point(34, 316);
            this.lblNome2.Name = "lblNome2";
            this.lblNome2.Size = new System.Drawing.Size(418, 25);
            this.lblNome2.TabIndex = 9;
            this.lblNome2.Text = "Nome: Murilo Bertoni Ismirim RA: 0030482313025";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(34, 272);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(476, 25);
            this.lblNome.TabIndex = 8;
            this.lblNome.Text = "Nome: Deivid Alessandro Dias Gomes RA: 0030482313018";
            // 
            // lblObjetivo
            // 
            this.lblObjetivo.AutoSize = true;
            this.lblObjetivo.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObjetivo.Location = new System.Drawing.Point(11, 115);
            this.lblObjetivo.Name = "lblObjetivo";
            this.lblObjetivo.Size = new System.Drawing.Size(777, 152);
            this.lblObjetivo.TabIndex = 14;
            this.lblObjetivo.Text = resources.GetString("lblObjetivo.Text");
            this.lblObjetivo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblObjetivo.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PDespesas0030482313018.Properties.Resources.raf_360x360_075_t_fafafa_ca443f4786;
            this.pictureBox2.Location = new System.Drawing.Point(527, 194);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(261, 244);
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PDespesas0030482313018.Properties.Resources.transferir;
            this.pictureBox1.Location = new System.Drawing.Point(304, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(185, 109);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblObjetivo);
            this.Controls.Add(this.lblNome6);
            this.Controls.Add(this.lblNome5);
            this.Controls.Add(this.lblNome4);
            this.Controls.Add(this.lblNome2);
            this.Controls.Add(this.lblNome);
            this.Name = "frmSobre";
            this.ShowIcon = false;
            this.Text = "Sobre";
            this.Load += new System.EventHandler(this.frmSobre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome6;
        private System.Windows.Forms.Label lblNome5;
        private System.Windows.Forms.Label lblNome4;
        private System.Windows.Forms.Label lblNome2;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblObjetivo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}