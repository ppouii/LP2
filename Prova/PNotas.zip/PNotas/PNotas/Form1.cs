﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
  //((auxiliar != "A") || (auxiliar != "B") || (auxiliar != "C") || (auxiliar != "D") || (auxiliar != "E")))

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {

            string auxiliar = "";
            Char[] resposta = new char [11];
            string[] gabarito = { "A","E","D","A","B","C","A","D","E","B"};


            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com a resposta da questão {i + 1}", "Entrada das Respostas");
                if (((auxiliar == "A") || (auxiliar == "B") || (auxiliar == "C") || (auxiliar == "D") || (auxiliar == "E")))
                {
                    if (auxiliar == gabarito[i])
                    {
                        resposta[i] = auxiliar[0];
                        lstbxRespostas.Items.Add($"O aluno: 1 acertou a questão {i + 1}, ele respondeu {resposta[i]} e a resposta é {gabarito[i]}" + "\n");
                    }
                    else if(auxiliar!=gabarito[i])
                    {
                        resposta[i] = auxiliar[0];
                        lstbxRespostas.Items.Add($"O aluno: 1 errou a questão {i + 1}, ele respondeu {resposta[i]} e a resposta é {gabarito[i]}" + "\n");
                    }

                }
                else
                {
                    MessageBox.Show("Digite uma resposta Válida");
                    i--;
                }
            }
           

        }
    }
}
